package p

import (
	_ "q/y"
	_ "q/z"
)
