package y

import _ "x"
