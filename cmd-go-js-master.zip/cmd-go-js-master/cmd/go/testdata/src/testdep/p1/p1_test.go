package p1

import _ "testdep/p2"
