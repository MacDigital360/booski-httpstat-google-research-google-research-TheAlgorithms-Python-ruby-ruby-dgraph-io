package p2

import _ "testdep/p3"
