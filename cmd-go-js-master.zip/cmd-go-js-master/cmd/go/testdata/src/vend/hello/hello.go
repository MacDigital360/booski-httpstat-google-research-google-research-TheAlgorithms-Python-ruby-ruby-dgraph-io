package main

import (
	"fmt"
	"strings" // really ../vendor/strings
)

func main() {
	fmt.Printf("%s\n", strings.Msg)
}
