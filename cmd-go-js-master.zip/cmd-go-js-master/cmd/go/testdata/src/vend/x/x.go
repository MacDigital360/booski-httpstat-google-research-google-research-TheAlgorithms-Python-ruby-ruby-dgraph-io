package x

import _ "p"
import _ "q"
import _ "r"
