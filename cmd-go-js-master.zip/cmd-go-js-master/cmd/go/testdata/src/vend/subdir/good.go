package subdir

import _ "p"
