package q1

import "testing"
import _ "testcycle/q1"

func Test(t *testing.T) {}
