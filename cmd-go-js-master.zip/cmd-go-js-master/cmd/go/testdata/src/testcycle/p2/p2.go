package p2

import _ "testcycle/p3"

func init() {
	println("p2 init")
}
