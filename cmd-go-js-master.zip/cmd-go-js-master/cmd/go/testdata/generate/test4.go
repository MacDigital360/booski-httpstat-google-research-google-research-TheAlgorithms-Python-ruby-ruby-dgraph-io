// Copyright 2015 The Go Authors.  All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Test -run flag

//go:generate echo oh yes my man
//go:generate echo no, no, a thousand times no

package p
