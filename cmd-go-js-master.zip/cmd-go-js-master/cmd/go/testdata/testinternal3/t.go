package t

import _ "internal/does-not-exist"
