puts "Olá Ruby!"
