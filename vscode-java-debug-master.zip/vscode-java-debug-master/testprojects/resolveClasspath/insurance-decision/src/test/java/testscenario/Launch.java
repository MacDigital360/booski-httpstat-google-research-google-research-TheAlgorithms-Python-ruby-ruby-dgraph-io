package testscenario;

public class Launch {

    public static void main(String[] args) {
        System.out.println("Main Class in Test Folder!");
    }
}