package com.github.kdvolder.helloworldservice;

public class Constants {
    public static final String GREETER_ID = "greeets";
}