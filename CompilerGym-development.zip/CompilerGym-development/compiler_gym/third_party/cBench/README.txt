The Collective Benchmark (cBench) suite.

Homepage: http://ctuning.org/wiki/index.php/CTools:CBench
Download: http://downloads.sourceforge.net/project/cbenchmark/cBench/V1.1/cBench_V1.1.tar.gz
License: GNU General Public License Version 2
Version: V1.1
