This directory contains code from this publication:

    Huang, Q., Haj-ali, A., Moses, W., Xiang, J., Stoica, I., Asanovic, K., &
    Wawrzynek, J. (2019). AutoPhase : Compiler Phase-Ordering for High-Level
    Synthesis with Deep Reinforcement Learning. FSEE.

Upstream: https://github.com/ucb-bar/autophase
License: BSD 3-Clause License
Git commit: 2f2e61ad63b50b5d0e2526c915d54063efdc2b92
