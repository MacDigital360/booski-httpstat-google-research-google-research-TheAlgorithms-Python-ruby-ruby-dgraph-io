Fixes #{issue number}
