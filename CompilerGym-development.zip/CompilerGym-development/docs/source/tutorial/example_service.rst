Adding support for a new compiler
=================================

This tutorial describes the process of writing a service to support a
new compiler.

.. warning::
   This tutorial covers advanced topics and uses a C++. Because the
   C++ API is not yet mature, we recommend that support for new
   compilers is merged into the upstream development branch so that
   future changes will not break it.

TODO.
