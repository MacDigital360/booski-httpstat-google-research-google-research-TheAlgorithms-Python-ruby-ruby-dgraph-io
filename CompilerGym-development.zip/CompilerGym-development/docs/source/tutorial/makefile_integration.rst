LLVM Makefile Integration
=========================

TODO.
